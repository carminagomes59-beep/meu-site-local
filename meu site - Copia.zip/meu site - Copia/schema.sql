-- Usuários
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Produtos
CREATE TABLE IF NOT EXISTS produtos (
    id TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    preco REAL NOT NULL
);

-- Inserir produtos iniciais
INSERT OR IGNORE INTO produtos (id, nome, preco) VALUES
('000001', 'Suco C', 4.50),
('000010', 'Suco P', 5.00),
('000011', 'Água mineral', 2.00),
('000100', 'Água com gás', 2.50),
('000101', 'Guaraná', 4.00),
('000110', 'Água tônica', 4.20),
('000111', 'Coca-Cola', 5.50),
('001000', 'Monster', 8.00),
('001001', 'Red Bull', 10.00),
('001010', 'Todinho', 3.50),
('001011', 'Extra', 12.99),
('001100', 'Detergente', 2.50),
('001101', 'Sabão em pó', 10.00),
('001110', 'Amaciante', 8.50),
('001111', 'Água sanitária', 4.00),
('010000', 'Desinfetante', 5.50),
('010001', 'Veja Multiuso', 7.00),
('010010', 'Esponja', 1.50),
('010011', 'Desengordurante', 9.00),
('010100', 'Saco de lixo', 8.00),
('010101', 'Pipoca', 3.00),
('010110', 'Bolacha', 2.50),
('010111', 'Biscoito', 2.50),
('011000', 'Bolo de padaria', 6.00),
('011001', 'Chiclete', 1.00),
('011010', 'Pirulito', 0.80),
('011011', 'Fini', 5.00),
('011100', 'Barra de chocolate', 6.50),
('011110', 'Pururuca', 4.00),
('011111', 'Paçoca', 1.50);
