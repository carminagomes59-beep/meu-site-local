from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "segredo"

DB = "loja.db"

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

# Inicializar banco manualmente
def inicializar_banco():
    db = get_db()
    with open("schema.sql", "r", encoding="utf-8") as f:
        db.executescript(f.read())
    db.commit()
    db.close()

# Chamar a inicialização do banco **quando o app inicia**
with app.app_context():
    inicializar_banco()

# --- ROTAS ---
@app.route("/")
def index():
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    erro = None
    if request.method == "POST":
        username = request.form["username"]
        senha = request.form["password"]
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        db.close()
        if user and check_password_hash(user["password_hash"], senha):
            session["user"] = username
            return redirect(url_for("dashboard"))
        else:
            erro = "Usuário ou senha inválidos"
    return render_template("login.html", erro=erro)

@app.route("/register", methods=["GET", "POST"])
def register():
    erro = None
    if request.method == "POST":
        username = request.form["username"]
        senha = request.form["password"]
        db = get_db()
        try:
            db.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)",
                       (username, generate_password_hash(senha)))
            db.commit()
            db.close()
            flash("Cadastro realizado com sucesso!", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            erro = "Nome de usuário já existe"
            db.close()
    return render_template("register.html", erro=erro)

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    db = get_db()
    produtos = db.execute("SELECT * FROM produtos").fetchall()
    db.close()
    return render_template("dashboard.html", produtos=produtos, usuario=session["user"])

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
